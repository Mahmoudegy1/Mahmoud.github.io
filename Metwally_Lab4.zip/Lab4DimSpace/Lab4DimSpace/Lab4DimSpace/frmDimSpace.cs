﻿using Lab4DimSpace.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4DimSpace
{
    public partial class frmDimSpace : Form
    {
        //Global variables to handle context and logged in user
        private User loggedInUser;
        private CollegeContext context;

        public frmDimSpace()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadContextData();
            SetInitialFormContents();
        }

        private void LoadContextData()
        {
            //load in contexts
            using (var context = new CollegeContext())
            {
                //Load courses into the Active Course combo box
                cboActiveCourse.DataSource = context.Courses.ToList();
                cboActiveCourse.DisplayMember = "CourseName";
                cboActiveCourse.ValueMember = "CourseId";
            }
        }

        private void SetInitialFormContents()
        {
            //code to setup initial form look for login
            tabNavigation.TabPages.Clear();
            tabNavigation.TabPages.Add(tabLogin);
            grpLoginInfo.Visible = true;
            grpActiveCourse.Visible = false;
            grpSearch.Visible = false;
            txtUsername.Text = "";
            txtPassword.Text = "";

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //Code to handle user login
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            CollegeContext context = new CollegeContext();

            loggedInUser = context.Users
                .Include(u => u.UserRole)
                .FirstOrDefault(u => u.Username == username && u.Password == password);

            if (loggedInUser != null)
            {
                lblUserName.Text = loggedInUser.Username;
                SetFormContentsForRole(loggedInUser.UserRole.Name);
                tabNavigation.TabPages.Remove(tabLogin);
            }
            else
            {
                MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            context.Dispose();
        }
        private void btnLogOut_Click(object sender, EventArgs e)
        {
            //Code to handle user logout
            loggedInUser = null;
            SetInitialFormContents();

        }

        private void btnCreateAssignment_Click(object sender, EventArgs e)
        {
            //code here to create a new assignment dropbox **NOTE** only an INSTRUCTOR should be able to do this!

        }

        private void btnSubmitAssignment_Click(object sender, EventArgs e)
        {
            //code here to submit an existing assignment **NOTE** only a STUDENT should be able to do this!
            int rowIndex = dgvAssignments.CurrentCell.RowIndex;
            int selectedItem = Convert.ToInt32(dgvAssignments.Rows[rowIndex].Cells[0].Value.ToString());
            var query = context.DropBoxItems.Where(x => x.DropBoxItemId == selectedItem).FirstOrDefault();
            if (query != null)
            {
                if (query.StatusId == 1)
                {
                    
                    query.StatusId = 2;
                    context.SaveChanges();
                    LoadContextData();
                    dgvAssignments.Refresh();
                    MessageBox.Show($"submitted Assignment: {query.DropBox.Name}", "Success");
                }
                else
                {
                    MessageBox.Show("Unable to submit");
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            //Search Code
        }

        private void cboActiveCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedCourseId = (int)cboActiveCourse.SelectedValue;
            CollegeContext context = new CollegeContext();

            if (tabNavigation.SelectedTab == tabUsers)
            {
                //Load users 
                var users = context.CourseAccesses
                    .Where(ca => ca.CourseId == selectedCourseId)
                    .Select(ca => ca.User)
                    .ToList();

                dgvUsers.DataSource = users;
            }
            else if (tabNavigation.SelectedTab == tabAssignments)
            {
                //Load assignments 
                var assignments = context.DropBoxItems
                    .Include(dbi => dbi.DropBox)
                    .Where(dbi => dbi.DropBox.CourseId == selectedCourseId)
                    .Select(dbi=> dbi.DropBox)
                    .ToList();

                dgvAssignments.DataSource = assignments;
            }

            context.Dispose();
        }

        private void btnCreateUser_Click(object sender, EventArgs e)
        {
            //Code to create a new user **NOTE** only an Admin should be able to do this
            if (loggedInUser.UserRole.Name == "Administrator") 
            {
                
                User user = new User();
                user.Username = txtUsers.Text;
                user.Password = txtUsers.Text;
                user.Email = txtUsers.Text + "@mynbcc.ca";
                if (radStudent.Checked)
                    user.UserRoleId = 1;
                else
                    user.UserRoleId = 2;

                var course = context.Courses.FirstOrDefault(x => x.Name == cboActiveCourse.Text);
                if (course != null)
                {
                    CourseAccess courseAccess = new CourseAccess();
                    courseAccess.User = user;
                    courseAccess.Course = course;
                    context.Users.Add(user);
                    context.CourseAccesses.Add(courseAccess);
                    context.SaveChanges();
                    LoadContextData();
                }
                else
                {
                    MessageBox.Show("Please select a valid course.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void btnAssignUser_Click(object sender, EventArgs e)
        {
            //Code to assign displayed user to active course **NOTE** only an Admin should be able to do this

        }
        private void SetFormContentsForRole(string role)
        {
            //display content 
            tabNavigation.TabPages.Add(tabUsers);
            tabNavigation.TabPages.Add(tabAssignments);

            //Make the group boxes visible for all roles except Admin on login
            grpLoginInfo.Visible = true;
            grpActiveCourse.Visible = true;
            grpSearch.Visible = true;

            if (role == "Administrator")
            {
                tabNavigation.TabPages.Remove(tabAssignments);
                grpUserManagement.Visible = true;
            }
            else if (role == "Instructor")
            {
                grpUserManagement.Visible = false;
                btnSubmitAssignment.Visible = false;
                grpCreateAssignment.Visible = true;
            }
            else if (role == "Student")
            {
                tabNavigation.TabPages.Remove(tabUsers);
                grpCreateAssignment.Visible = false;
                grpUserManagement.Visible = false;
                btnSubmitAssignment.Visible = true;
            }
        }
    }
}

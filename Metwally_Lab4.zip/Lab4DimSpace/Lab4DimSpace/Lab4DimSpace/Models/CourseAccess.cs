﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Lab4DimSpace.Models;

[Table("CourseAccess")]
public partial class CourseAccess
{
    [Key]
    public int CourseAccessId { get; set; }

    public int UserId { get; set; }

    public int CourseId { get; set; }

    [ForeignKey("CourseId")]
    [InverseProperty("CourseAccesses")]
    public virtual Course Course { get; set; } = null!;

    [ForeignKey("UserId")]
    [InverseProperty("CourseAccesses")]
    public virtual User User { get; set; } = null!;
}

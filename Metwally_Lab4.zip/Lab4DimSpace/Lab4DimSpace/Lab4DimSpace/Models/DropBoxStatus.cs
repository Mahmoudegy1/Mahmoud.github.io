﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Lab4DimSpace.Models;

[Table("DropBoxStatus")]
public partial class DropBoxStatus
{
    [Key]
    public int StatusId { get; set; }

    [StringLength(30)]
    [Unicode(false)]
    public string? StatusName { get; set; }

    [InverseProperty("Status")]
    public virtual ICollection<DropBoxItem> DropBoxItems { get; set; } = new List<DropBoxItem>();
}

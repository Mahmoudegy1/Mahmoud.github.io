﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Lab4DimSpace.Models;

public partial class DropBoxItem
{
    [Key]
    public int DropBoxItemId { get; set; }

    public int DropBoxId { get; set; }

    public int StudentId { get; set; }

    public int StatusId { get; set; }

    [ForeignKey("DropBoxId")]
    [InverseProperty("DropBoxItems")]
    public virtual DropBox DropBox { get; set; } = null!;

    [ForeignKey("StatusId")]
    [InverseProperty("DropBoxItems")]
    public virtual DropBoxStatus Status { get; set; } = null!;

    [ForeignKey("StudentId")]
    [InverseProperty("DropBoxItems")]
    public virtual User Student { get; set; } = null!;
}

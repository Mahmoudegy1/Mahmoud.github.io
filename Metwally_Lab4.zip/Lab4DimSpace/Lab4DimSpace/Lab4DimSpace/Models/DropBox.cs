﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Lab4DimSpace.Models;

[Table("DropBox")]
public partial class DropBox
{
    [Key]
    public int DropBoxId { get; set; }

    public int? CourseId { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string Name { get; set; } = null!;

    [StringLength(255)]
    [Unicode(false)]
    public string? Description { get; set; }

    public DateOnly? DueDate { get; set; }

    [ForeignKey("CourseId")]
    [InverseProperty("DropBoxes")]
    public virtual Course? Course { get; set; }

    [InverseProperty("DropBox")]
    public virtual ICollection<DropBoxItem> DropBoxItems { get; set; } = new List<DropBoxItem>();
}

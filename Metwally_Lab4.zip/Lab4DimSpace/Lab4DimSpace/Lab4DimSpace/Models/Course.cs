﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Lab4DimSpace.Models;

public partial class Course
{
    [Key]
    public int CourseId { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string Name { get; set; } = null!;

    [StringLength(255)]
    [Unicode(false)]
    public string? Description { get; set; }

    [InverseProperty("Course")]
    public virtual ICollection<CourseAccess> CourseAccesses { get; set; } = new List<CourseAccess>();

    [InverseProperty("Course")]
    public virtual ICollection<DropBox> DropBoxes { get; set; } = new List<DropBox>();
}

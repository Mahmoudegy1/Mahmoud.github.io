﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Lab4DimSpace.Models;


public partial class CollegeContext : DbContext
{

    public CollegeContext()
    {
    }


    public CollegeContext(DbContextOptions<CollegeContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Course> Courses { get; set; }

    public virtual DbSet<CourseAccess> CourseAccesses { get; set; }

    public virtual DbSet<DropBox> DropBoxes { get; set; }

    public virtual DbSet<DropBoxItem> DropBoxItems { get; set; }

    public virtual DbSet<DropBoxStatus> DropBoxStatuses { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserRole> UserRoles { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=(local)\\SQLEXPRESS;Initial Catalog=DimSpace;Integrated Security=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Course>(entity =>
        {
            entity.HasKey(e => e.CourseId).HasName("PK__Courses__C92D71A742E90AD6");
        });

        modelBuilder.Entity<CourseAccess>(entity =>
        {
            entity.HasKey(e => e.CourseAccessId).HasName("PK__CourseAc__14EFAA09D904F12E");

            entity.HasOne(d => d.Course).WithMany(p => p.CourseAccesses)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__CourseAcc__Cours__412EB0B6");

            entity.HasOne(d => d.User).WithMany(p => p.CourseAccesses)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__CourseAcc__UserI__403A8C7D");
        });

        modelBuilder.Entity<DropBox>(entity =>
        {
            entity.HasKey(e => e.DropBoxId).HasName("PK__DropBox__27F13A3D222DE624");

            entity.HasOne(d => d.Course).WithMany(p => p.DropBoxes).HasConstraintName("FK__DropBox__CourseI__440B1D61");
        });

        modelBuilder.Entity<DropBoxItem>(entity =>
        {
            entity.HasKey(e => e.DropBoxItemId).HasName("PK__DropBoxI__07D28D5E6F72C24D");

            entity.HasOne(d => d.DropBox).WithMany(p => p.DropBoxItems)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__DropBoxIt__DropB__46E78A0C");

            entity.HasOne(d => d.Status).WithMany(p => p.DropBoxItems)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__DropBoxIt__Statu__48CFD27E");

            entity.HasOne(d => d.Student).WithMany(p => p.DropBoxItems)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__DropBoxIt__Stude__47DBAE45");
        });

        modelBuilder.Entity<DropBoxStatus>(entity =>
        {
            entity.HasKey(e => e.StatusId).HasName("PK__DropBoxS__C8EE2063CE396B20");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__Users__1788CC4C8E3C6802");

            entity.HasOne(d => d.UserRole).WithMany(p => p.Users)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Users__UserRoleI__3D5E1FD2");
        });

        modelBuilder.Entity<UserRole>(entity =>
        {
            entity.HasKey(e => e.UserRoleId).HasName("PK__UserRole__3D978A359E075DBC");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using Lab4DimSpace.Models;
namespace Lab4DimSpace.Models;

public partial class User
{
    [Key]
    public int UserId { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string Username { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string Password { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string Email { get; set; } = null!;

    public int UserRoleId { get; set; }

    [InverseProperty("User")]
    public virtual ICollection<CourseAccess> CourseAccesses { get; set; } = new List<CourseAccess>();

    [InverseProperty("Student")]
    public virtual ICollection<DropBoxItem> DropBoxItems { get; set; } = new List<DropBoxItem>();

    [ForeignKey("UserRoleId")]
    [InverseProperty("Users")]
    public virtual UserRole UserRole { get; set; } = null!;
}
package A4_Flights;

public abstract class Flight implements PolicyRules {
    protected String flightNumber;
    protected Location destination;
    protected int crewCount;
    protected String day;
    protected int departureTime;

    public Flight(String flightNumber, Location destination, int crewCount, String day, int departureTime) {
        this.flightNumber = flightNumber;
        this.destination = destination;
        this.crewCount = crewCount;
        this.day = day;
        this.departureTime = departureTime;
    }

    // Method to calculate the weight of the flight
    public int calculateWeight() {
        return crewCount * Common.AVERAGE_PERSON_WEIGHT;
    }

    // Display report
    public String toDisplayReport() {
        return String.format("%s Flight = %s, Day = %s, Time = %d\n" +
                        "    Destination: %s (%s, %s), region %d\n" +
                        "    Number of Crew: %d",
                getFlightType(), flightNumber, day, departureTime,
                destination.getLocationCode(), destination.getCity(), destination.getCountry(), destination.getRegion(),
                crewCount);
    }

    // Archive format
    public String toArchiveFormat() {
        return String.format("%s,%s,%s,%d,%s,%d",
                getFlightType(), flightNumber, day, departureTime, destination.getLocationCode(), crewCount);
    }

    // Abstract method to get flight type
    public abstract String getFlightType();

    // Implementing PolicyRules methods
    @Override
    public boolean checkCrew() {
        return crewCount >= Common.MINIMUM_CREW;
    }

    @Override
    public boolean checkPassengers() {
        return true;  // Default, overridden in PassengerFlight
    }

    @Override
    public boolean checkTime() {
        return departureTime >= Common.EARLIEST_DEPARTURE && departureTime <= Common.LATEST_DEPARTURE;
    }

    @Override
    public boolean checkWeight() {
        return calculateWeight() <= Common.MAXIMUM_WEIGHT;
    }
}

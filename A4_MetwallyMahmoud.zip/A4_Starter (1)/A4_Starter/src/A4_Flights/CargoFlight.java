package A4_Flights;

public class CargoFlight extends Flight {
    private int cargoWeight;

    public CargoFlight(String flightNumber, Location destination, int crewCount, String day, int departureTime, int cargoWeight) {
        super(flightNumber, destination, crewCount, day, departureTime);
        this.cargoWeight = cargoWeight;
    }

    @Override
    public int calculateWeight() {
        return super.calculateWeight() + cargoWeight;
    }

    @Override
    public String toDisplayReport() {
        return super.toDisplayReport() + String.format("\n    Cargo Weight: %d\n    Total Weight: %d",
                cargoWeight, calculateWeight());
    }

    @Override
    public String toArchiveFormat() {
        return super.toArchiveFormat() + String.format(",%d", cargoWeight);
    }

    @Override
    public String getFlightType() {
        return "Cargo";
    }

    @Override
    public boolean checkPassengers() {
        return true;  // No passengers in CargoFlight
    }
}

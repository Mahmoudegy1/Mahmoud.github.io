package A4_Flights;

public class PassengerFlight extends Flight {
    private int passengerCount;

    public PassengerFlight(String flightNumber, Location destination, int crewCount, String day, int departureTime, int passengerCount) {
        super(flightNumber, destination, crewCount, day, departureTime);
        this.passengerCount = passengerCount;
    }

    @Override
    public int calculateWeight() {
        return super.calculateWeight() + (passengerCount * Common.AVERAGE_PERSON_WEIGHT);
    }

    @Override
    public String toDisplayReport() {
        return super.toDisplayReport() + String.format("\n    Passengers: %d\n    Total Weight: %d",
                passengerCount, calculateWeight());
    }

    @Override
    public String toArchiveFormat() {
        return super.toArchiveFormat() + String.format(",%d", passengerCount);
    }

    @Override
    public String getFlightType() {
        return "Passenger";
    }

    @Override
    public boolean checkPassengers() {
        return passengerCount >= Common.MINIMUM_PASSENGERS;
    }
}

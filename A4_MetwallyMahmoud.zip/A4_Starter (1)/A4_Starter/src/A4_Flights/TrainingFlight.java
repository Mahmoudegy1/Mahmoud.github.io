package A4_Flights;

public class TrainingFlight extends Flight {
    public TrainingFlight(String flightNumber, Location destination, int crewCount, String day, int departureTime) {
        super(flightNumber, destination, crewCount, day, departureTime);
    }

    @Override
    public String toDisplayReport() {
        return super.toDisplayReport() + String.format("\n    Total Weight: %d", calculateWeight());
    }

    @Override
    public String getFlightType() {
        return "Training";
    }

    @Override
    public boolean checkTime() {
        return departureTime >= Common.EARLIEST_DEPARTURE && departureTime <= Common.LATEST_DEPARTURE;
    }
}

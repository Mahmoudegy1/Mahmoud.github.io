import React from "react";

export function ButtonPanel({
  addClickHandler,
  updateClickHandler,
  deleteClickHandler,
  selectedItem,
}) {
  return (
    <div>
      <button
        className="btn btn-outline-primary me-2"
        onClick={addClickHandler}
      >
        Add
      </button>
      <button
        className="btn btn-outline-primary me-2"
        onClick={updateClickHandler}
        disabled={!selectedItem}
      >
        Update
      </button>
      <button
        className="btn btn-outline-danger"
        onClick={deleteClickHandler}
        disabled={!selectedItem}
      >
        Delete
      </button>
    </div>
  );
}
import React from "react";

export function MenuTable({ menuItems, tableClickHandler, selectedItem }) {
  return (
    <table className="table table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Category</th>
          <th>Description</th>
          <th>Price</th>
          <th>Vegetarian</th>
        </tr>
      </thead>
      <tbody>
        {menuItems.map((item) => (
          <tr
            key={item.id}
            onClick={() => tableClickHandler(item)}
            className={item === selectedItem ? "table-primary" : ""}
          >
            <td>{item.id}</td>
            <td>{item.category}</td>
            <td>{item.description}</td>
            <td>{item.price}</td>
            <td>{item.vegetarian ? "Yes" : "No"}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
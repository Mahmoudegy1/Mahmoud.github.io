import React from 'react';

export function AddUpdatePanel({
  selectedItem,
  panelItem,
  inputChangeHandler,
  doneClickHandler,
  resetClickHandler,
  cancelClickHandler,
}) {
  const isUpdateMode = !!selectedItem;

  return (
    <div>
      <div className="form-group mb-3">
        <label htmlFor="id" className="form-label">
          ID
        </label>
        <input
          type="number"
          className="form-control"
          id="id"
          value={panelItem?.id || ''}
          onChange={(e) => inputChangeHandler('id', e.target.value)}
          disabled={isUpdateMode}
        />
      </div>
      <div className="form-group mb-3">
        <label htmlFor="category" className="form-label">
          Category
        </label>
        <input
          type="text"
          className="form-control"
          id="category"
          value={panelItem?.category || ''}
          onChange={(e) => inputChangeHandler('category', e.target.value)}
        />
      </div>
      <div className="form-group mb-3">
        <label htmlFor="description" className="form-label">
          Description
        </label>
        <input
          type="text"
          className="form-control"
          id="description"
          value={panelItem?.description || ''}
          onChange={(e) => inputChangeHandler('description', e.target.value)}
        />
      </div>
      <div className="form-group mb-3">
        <label htmlFor="price" className="form-label">
          Price
        </label>
        <input
          type="number"
          className="form-control"
          id="price"
          value={panelItem?.price || ''}
          onChange={(e) => inputChangeHandler('price', e.target.value)}
        />
      </div>
      <div className="form-group mb-3">
        <label htmlFor="vegetarian" className="form-label">
          Vegetarian
        </label>
        <input
          type="checkbox"
          className="form-check-input"
          id="vegetarian"
          checked={panelItem?.vegetarian || false}
          onChange={(e) => inputChangeHandler('vegetarian', e.target.checked)}
        />
      </div>
      <div className="form-group">
        <button className="btn btn-primary me-2" onClick={doneClickHandler}>
          Done
        </button>
        <button className="btn btn-secondary me-2" onClick={resetClickHandler}>
          Reset
        </button>
        <button className="btn btn-danger" onClick={cancelClickHandler}>
          Cancel
        </button>
      </div>
    </div>
  );
}
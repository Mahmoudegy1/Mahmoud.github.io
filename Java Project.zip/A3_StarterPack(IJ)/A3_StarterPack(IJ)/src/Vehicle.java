/**
 * A vehicle being transported on a ferry.
 */
public class Vehicle {

    private Passenger owner;
    private String type;
    private int weight;

    /**
     * Creates a new vehicle.
     * 
     * @param owner the owner of the vehicle
     * @param type the vehicle's type (Car or Truck)
     * @param weight the vehicle's weight
     */
    public Vehicle(Passenger owner, String type, int weight) {
        this.owner = owner;
        this.type = type;
        this.weight = weight;
    }

    public Passenger getOwner() {
        return owner;
    }

    public String getType() {
        return type;
    }
    
    public int getWeight() {
        return weight;
    }


    /**
     * Creates a string of the form "Vehicle Type: ____, Weight: ____, Owner: ____"
     * 
     * @return the formatted string
     */
    @Override
    public String toString() {
        return "Vehicle Type: " + type + ", Weight: " + weight + ", Owner: " + owner.toString();
    }
            
} // end class Vehicle

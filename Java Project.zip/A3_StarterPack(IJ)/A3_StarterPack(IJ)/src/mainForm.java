import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.IOException;

public class mainForm extends JFrame {

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                mainForm main = new mainForm();
                main.mainPanel.setVisible(true);
            }
        });
    }

    Ferry ferry = null;
    ArrayList<String> rejections = new ArrayList<>();

    private JPanel mainPanel;
    private JTextField txtFerryName;
    private JTextField txtCarLimit;
    private JTextField txtFile;
    private JTextField txtRejectionsFile;
    private JButton btnLoad;
    private JTextField txtPassengerLimit;
    private JTextField txtTruckLimit;
    private JButton btnCreateFerry;
    private JButton btnPresets;
    private JComboBox cbxPresets;
    private JTextArea txtStatus;
    private JButton btnShowPassengers;
    private JButton btnShowCars;
    private JButton btnShowTrucks;
    private JButton btnShowRejections;
    private JTextArea txtOutput;

    public mainForm() {
        setContentPane(mainPanel);
        setTitle("Java - Assignment 3");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);
        setVisible(true);

        btnPresets.setMnemonic((int)'S');
        btnCreateFerry.setMnemonic((int)'F');
        btnLoad.setMnemonic((int)'L');
        btnShowCars.setMnemonic((int)'C');
        btnShowPassengers.setMnemonic((int)'P');
        btnShowTrucks.setMnemonic((int)'T');
        btnShowRejections.setMnemonic((int)'R');

        btnPresets.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cbxPresets.requestFocus();
            }
        });

        btnCreateFerry.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // *** DO NOT MODIFY THIS METHOD ***//
                try {
                    String name = txtFerryName.getText();
                    int passengerLimit = Integer.parseInt(txtPassengerLimit.getText());
                    int carLimit = Integer.parseInt(txtCarLimit.getText());
                    int truckLimit = Integer.parseInt(txtTruckLimit.getText());

                    ferry = new Ferry(name, passengerLimit, carLimit, truckLimit);
                    txtStatus.setText(ferry.generateStatusReport());
                } catch (Exception ex) {
                    txtStatus.setText("Oops - there was a problem :(");
                }
                // *** DO NOT MODIFY THIS METHOD ***//

            }
        });
        btnLoad.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // *** DO NOT MODIFY THIS METHOD ***//
                if (ferry == null) {
                    txtStatus.setText("Please create the ferry first ...");
                } else {
                    loadFerry(txtFile.getText());
                    txtStatus.setText(ferry.generateStatusReport());
                }
                //** DO NOT MODIFY THIS METHOD ***//

            }
        });
        btnShowPassengers.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtOutput.setText("Passenger Report\n");
                if (ferry != null) {
                    Passenger[] passengers = ferry.getPassengers();
                    for (int i = 0; i < passengers.length; i++) {
                        if (passengers[i] != null) {
                            txtOutput.append((i + 1) + ". " + passengers[i].toString() + "\n");
                        }
                    }
                } else {
                    txtOutput.append("Ferry not created yet.");
                }
            }
        });
        btnShowCars.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtOutput.setText("Car Report\n");
                if (ferry != null) {
                    Vehicle[] cars = ferry.getCars();
                    for (int i = 0; i < cars.length; i++) {
                        if (cars[i] != null) {
                            txtOutput.append((i + 1) + ". " + cars[i].toString() + "\n");
                        }
                    }
                } else {
                    txtOutput.append("Ferry not created yet.");
                }
            }
        });
        btnShowTrucks.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtOutput.setText("Truck Report\n");
                if (ferry != null) {
                    Vehicle[] trucks = ferry.getTrucks();
                    for (int i = 0; i < trucks.length; i++) {
                        if (trucks[i] != null) {
                            txtOutput.append((i + 1) + ". " + trucks[i].toString() + "\n");
                        }
                    }
                } else {
                    txtOutput.append("Ferry not created yet.");
                }
            }
        });
        btnShowRejections.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                txtOutput.setText("Rejections Report\n");
                if (!rejections.isEmpty()) {
                    for (int i = 0; i < rejections.size(); i++) {
                        txtOutput.append((i + 1) + ". " + rejections.get(i) + "\n");
                    }
                } else {
                    txtOutput.append("No rejections to display.");
                }
                txtOutput.setCaretPosition(0);
            }
        });
        cbxPresets.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s = cbxPresets.getSelectedItem().toString();
                if (s.startsWith("1"))
                { txtPassengerLimit.setText("100"); txtCarLimit.setText("25"); txtTruckLimit.setText("7"); }
                if (s.startsWith("2"))
                { txtPassengerLimit.setText("100"); txtCarLimit.setText("25"); txtTruckLimit.setText("0"); }
                if (s.startsWith("3"))
                { txtPassengerLimit.setText("100"); txtCarLimit.setText("0"); txtTruckLimit.setText("7"); }
                if (s.startsWith("4"))
                { txtPassengerLimit.setText("100"); txtCarLimit.setText("0"); txtTruckLimit.setText("0"); }
                if (s.startsWith("5"))
                { txtPassengerLimit.setText("0"); txtCarLimit.setText("25"); txtTruckLimit.setText("7"); }
                if (s.startsWith("6"))
                { txtPassengerLimit.setText("0"); txtCarLimit.setText("0"); txtTruckLimit.setText("0"); }
            }
        });


    }

    /**
     * Loads the ferry with the passengers and vehicles contained in the
     * specified file.
     *
     * @param fileName the file containing the passenger and vehicle data.
     */
    private void loadFerry(String fileName) {
        rejections.clear();
        try (Scanner scanner = new Scanner(new File(fileName))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");

                if (parts.length >= 2) {
                    int id = Integer.parseInt(parts[0]);
                    SimpleDate dob = SimpleDate.parseDMY(parts[1]);
                    Passenger passenger = new Passenger(id, dob);

                    if (parts.length == 2) {
                        String result = ferry.loadPassenger(passenger);
                        if (result.startsWith(Constants.ERROR)) {
                            rejections.add(result + " - " + passenger);
                        }
                    } else if (parts.length == 4) {
                        String vehicleType = parts[2].toLowerCase();
                        int weight = Integer.parseInt(parts[3]);

                        Vehicle vehicle;
                        if (vehicleType.equals("car")) {
                            vehicle = new Vehicle(passenger, Constants.CAR, weight);
                        } else if (vehicleType.equals("truck")) {
                            vehicle = new Vehicle(passenger, Constants.TRUCK, weight);
                        } else {
                            rejections.add(Constants.ERROR + ": Unknown vehicle type - " + passenger);
                            continue;
                        }

                        String result = ferry.loadVehicle(vehicle);
                        if (result.startsWith(Constants.ERROR)) {
                            rejections.add(result + " - " + vehicle);
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            txtOutput.setText("Error: File not found - " + fileName);
            return;
        } catch (Exception e) {
            txtOutput.setText("Error reading file: " + e.getMessage());
            return;
        }

        try (PrintWriter writer = new PrintWriter(new File(txtRejectionsFile.getText()))) {
            for (String rejection : rejections) {
                writer.println(rejection);
            }
        } catch (IOException e) {
            txtOutput.setText("Error writing to rejections file: " + e.getMessage());
            return;
        }

        StringBuilder output = new StringBuilder("Loading complete.\n");
        output.append("Rejections: ").append(rejections.size()).append("\n\n");
        output.append("Rejection details:\n");
        for (String rejection : rejections) {
            output.append(rejection).append("\n");
        }
        txtOutput.setText(output.toString());
        txtOutput.setCaretPosition(0);
    }

}

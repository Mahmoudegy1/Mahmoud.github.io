/**
 * A ferry that transports vehicles and people
 */
public class Ferry {

    private String name;
    private Passenger[] passengers;
    private Vehicle[] cars;
    private Vehicle[] trucks;

    public Ferry(String name, int passengerSpaces, int carSpaces, int truckSpaces) {

        // TODO-A1: YOUR CODE HERE
        this.name = name;
        this.passengers = new Passenger[passengerSpaces];
        this.cars = new Vehicle[carSpaces];
        this.trucks = new Vehicle[truckSpaces];

    }

    /**
     * Creates a string containing information about this ferry. The string has.
     * the following form:
     *
     * ***** Status Report for Ferry ____ *****
     * Passengers: ____   Weight: ____
     * Cars:       ____   Weight: ____
     * Trucks:     ____   Weight: ____
     *              Total Weight: ____
     *
     * @return the reportStatus string
     */
    public String generateStatusReport() {
        int passengerCount = countNonNullElements(passengers);
        int carCount = countNonNullElements(cars);
        int truckCount = countNonNullElements(trucks);

        double passengerWeight = passengerCount * Constants.AVERAGE_PASSENGER_WEIGHT;
        double carWeight = calculateVehicleWeight(cars);
        double truckWeight = calculateVehicleWeight(trucks);
        double totalWeight = passengerWeight + carWeight + truckWeight;

        return String.format("***** Status Report for Ferry %s *****\n" +
                        "Passengers:\t%d\tWeight:\t%.2f\n" +
                        "Cars:\t\t%d\tWeight:\t%.2f\n" +
                        "Trucks:\t\t%d\tWeight:\t%.2f\n" +
                        "\t\t\tTotal Weight:\t%.2f",
                name, passengerCount, passengerWeight,
                carCount, carWeight,
                truckCount, truckWeight,
                totalWeight);
    }
    private int countNonNullElements(Object[] array) {
        int count = 0;
        for (Object obj : array) {
            if (obj != null) {
                count++;
            }
        }
        return count;
    }

    private double calculateVehicleWeight(Vehicle[] vehicles) {
        double weight = 0;
        for (Vehicle v : vehicles) {
            if (v != null) {
                weight += v.getWeight();
            }
        }
        return weight;
    }

    public String loadPassenger(Passenger p) {
        for (int i = 0; i < passengers.length; i++) {
            if (passengers[i] == null) {
                passengers[i] = p;
                return Constants.OK + ": Passenger loaded successfully.";
            }
        }
        return Constants.ERROR + ": No more room for passengers.";
    }
    private String checkPassengerSpace() {
        for (Passenger p : passengers) {
            if (p == null) return Constants.OK;
        }
        return Constants.ERROR + ": No room for vehicle owner as passenger.";
    }

    private String checkCarSpace() {
        for (Vehicle c : cars) {
            if (c == null) return Constants.OK;
        }
        return Constants.ERROR + ": No room for car.";
    }

    private String checkTruckSpace() {
        for (Vehicle t : trucks) {
            if (t == null) return Constants.OK;
        }
        return Constants.ERROR + ": No room for truck.";
    }

    public String loadVehicle(Vehicle v) {
        String passengerStatus = checkPassengerSpace();
        String vehicleStatus = (v.getType().equals(Constants.CAR)) ? checkCarSpace() : checkTruckSpace();

        if (vehicleStatus.equals(Constants.OK) && passengerStatus.equals(Constants.OK)) {
            loadPassenger(v.getOwner());

            if (v.getType().equals(Constants.CAR)) {
                for (int i = 0; i < cars.length; i++) {
                    if (cars[i] == null) {
                        cars[i] = v;
                        return Constants.OK + ": Vehicle and owner loaded successfully.";
                    }
                }
            } else {
                for (int i = 0; i < trucks.length; i++) {
                    if (trucks[i] == null) {
                        trucks[i] = v;
                        return Constants.OK + ": Vehicle and owner loaded successfully.";
                    }
                }
            }
        }

        if (!passengerStatus.equals(Constants.OK)) {
            return passengerStatus;
        } else {
            return vehicleStatus;
        }
    }

    public Passenger[] getPassengers() {
        return passengers;
    }

    public Vehicle[] getCars() {
        return cars;
    }

    public Vehicle[] getTrucks() {
        return trucks;
    }

} // end class Ferry

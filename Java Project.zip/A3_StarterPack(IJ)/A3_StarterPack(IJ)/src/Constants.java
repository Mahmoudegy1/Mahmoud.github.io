public class Constants {

    /** the average weight of a passenger */
    public static final int AVERAGE_PASSENGER_WEIGHT = 75;
    
    /** Vehicle type = "car" */
    public static final String CAR = "Car";
    
    /** Vehicle type = "truck" */
    public static final String TRUCK = "Truck";
    
    /** the label to use for a status message indicating successful loading */
    public static final String OK = "OK";
    
    /** the label to use for a status messages indicating a failed loading */
    public static final String ERROR = "ERROR";
    
} // end class Constants

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetwallyLap5
{
    namespace MetwallyLap5
    {
        internal class Program
        {
            static void Main(string[] args)
            {

                List<Package> deliveries = new List<Package>();

                DisplayPackages(deliveries);

                Weekly weeklyP1 = new Weekly();
                weeklyP1.From = new Client("NBCC", "100 Grand Avenue", "Saint John");
                weeklyP1.To = new Client(); 
                weeklyP1.Weight = 0;
                deliveries.Add(weeklyP1);

                Weekly weeklyP2 = new Weekly("Bob Barker", "2 Apple Road");
                weeklyP2.To = new Client(); 
                weeklyP2.Weight = 450.25m;
                weeklyP2.Discount = 0.15m;
                deliveries.Add(weeklyP2);

                Speedy speedy1 = new Speedy();
                speedy1.From = new Client("Greco", "8 Pizza Slices", "Fredericton");
                speedy1.To = new Client(); 
                speedy1.Weight = 5000.2m;
                deliveries.Add(speedy1);

                
                Speedy speedy2 = new Speedy("Haresh Komali", "17 Grape Juice");
                speedy2.To = new Client("Amazon", "22 Cloud", "Some City");
                speedy2.Weight = 899.9m;
                speedy2.ExtraCost = 0.035m;
                deliveries.Add(speedy2);


                DisplayPackages(deliveries);
            }

            static void DisplayPackages(List<Package> packages)
            {
                
            }
        }

        // Client class
        class Client
        {
            public string Name { get; set; }
            public string Address { get; set; }
            public string City { get; set; }

            public Client()
            {
                
                Name = "Mahmoud";
                Address = "Loch Lomond Rd";
                City = "Saint John";
            }

            
            public Client(string name, string address, string city)
            {
                Name = name;
                Address = address;
                City = city;
            }
        }

        //Base class Package
        abstract class Package
        {
            private static int NTrackingNumber = 1000;

            public int TrackingNumber { get; }
            public Client From { get; set; }
            public Client To { get; set; }
            private decimal weight;
            public decimal Weight
            {
                get { return weight; }
                set { weight = ValidateWeight(value); }
            }

          
            public Package()
            {
                TrackingNumber = NTrackingNumber;
                NTrackingNumber += 10;
                From = new Client();
                To = new Client();
            }

            protected decimal ValidateWeight(decimal weight)
            {
                if (weight < 450)
                    return 450;
                else if (weight > 5000)
                    return 5000;
                else
                    return weight;
            }

            
            public abstract decimal CalculateCost();
            public interface IWriteable
            {
                string WriteData();
            }
        }

        class Weekly : Package, Package.IWriteable
        {
            private decimal discount;
            public decimal Discount
            {
                get { return discount; }
                set { discount = value < 0.10m ? 0.10m : (value > 0.25m ? 0.25m : value); }
            }

            public Weekly()
            {
                Discount = 0; 
            }

            // Custom constructor
            public Weekly(string fromName, string fromAddress) : base()
            {
                From = new Client(fromName, fromAddress, ""); 
                Discount = 0; 
            }
            public override decimal CalculateCost()
            {
                
                return 0; 
            }

            public string WriteData()
            {
                return $"Package Type: Weekly\nTracking Number: {TrackingNumber}\nFrom: {From.Name}, {From.Address}, {From.City}\nTo: {To.Name}, {To.Address}, {To.City}\nWeight: {Weight} grams\nDiscount: {Discount * 100}%\n";
            }
        }

        // Speedy class
        class Speedy : Package, Package.IWriteable
        {
            private decimal _extraCost;
            public decimal ExtraCost
            {
                get { return _extraCost; }
                set { _extraCost = value < 0.01m ? 0.01m : (value > 0.04m ? 0.04m : value); }
            }

            // Default constructor
            public Speedy()
            {
                ExtraCost = 0; 
            }

            
            public Speedy(string fromName, string fromAddress) : base()
            {
                From = new Client(fromName, fromAddress, ""); 
                ExtraCost = 0; 
            }

           
            public override decimal CalculateCost()
            {
               
                return 0;
            }

            
            public string WriteData()
            {
                return $"Package Type: Speedy\nTracking Number: {TrackingNumber}\nFrom: {From.Name}, {From.Address}, {From.City}\nTo: {To.Name}, {To.Address}, {To.City}\nWeight: {Weight} grams\nExtra Cost: {ExtraCost}\n";
            }
        }
    }
}
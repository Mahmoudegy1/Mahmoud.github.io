<?php

class Player implements JsonSerializable
{
    private $playerID;
    private $name;
    private $age;
    private $position;
    private $goals;

    public function __construct($playerID, $name, $age, $position, $goals)
    {
        $this->playerID = $playerID;
        $this->name = $name;
        $this->age = $age;
        $this->position = $position;
        $this->goals = $goals;
    }

    public function getPlayerID()
    {
        return $this->playerID;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getAge()
    {
        return $this->age;
    }

    public function getPosition()
    {
        return $this->position;
    }

    public function getGoals()
    {
        return $this->goals;
    }

    // JsonSerializable implementation
    public function jsonSerialize(): mixed
    {
        return [
            'playerID' => $this->playerID,
            'name' => $this->name,
            'age' => $this->age,
            'position' => $this->position,
            'goals' => $this->goals,
        ];
    }
}

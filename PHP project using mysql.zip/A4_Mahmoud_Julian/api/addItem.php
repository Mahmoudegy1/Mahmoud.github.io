<?php
require_once dirname(__DIR__, 1) . '/db/ConnectionManager.php';
require_once dirname(__DIR__, 1) . '/db/PlayerAccessor.php'; 
require_once dirname(__DIR__, 1) . '/entity/Player.php'; 
require_once dirname(__DIR__, 1) . '/utils/Constants.php';

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if ($data) {
    try {
        $cm = new ConnectionManager(Constants::$MYSQL_CONNECTION_STRING, Constants::$MYSQL_USERNAME, Constants::$MYSQL_PASSWORD);
        $mia = new PlayerAccessor($cm->getConnection());

        $player = new Player(null, $data['Name'], $data['Age'], $data['Position'], $data['Goals']);
        $success = $mia->addPlayer($player);

        echo $success ? json_encode(["status" => "success"]) : json_encode(["status" => "error"]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid input."]);
}
?>

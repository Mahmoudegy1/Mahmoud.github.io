<?php
require_once dirname(__DIR__, 1) . '/db/ConnectionManager.php';
require_once dirname(__DIR__, 1) . '/db/PlayerAccessor.php'; 
require_once dirname(__DIR__, 1) . '/entity/Player.php'; 
require_once dirname(__DIR__, 1) . '/utils/Constants.php';

$id = intval($_GET['PlayerID']);
//only id matters
$playerObj = new Player($id, null, null, null, null); 

//delete from DB
try {
    $cm = new ConnectionManager(Constants::$MYSQL_CONNECTION_STRING, Constants::$MYSQL_USERNAME, Constants::$MYSQL_PASSWORD);
    $mia = new PlayerAccessor($cm->getConnection());
    $success = $mia->deletePlayer($playerObj);
    echo $success ? 1 : 0;
} catch (Exception $e) {
    echo "ERROR " . $e->getMessage();
}
?>

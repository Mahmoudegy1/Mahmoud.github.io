<?php
require_once dirname(__DIR__, 1) . '/db/ConnectionManager.php';
require_once dirname(__DIR__, 1) . '/db/PlayerAccessor.php'; 
require_once dirname(__DIR__, 1) . '/entity/Player.php'; 
require_once dirname(__DIR__, 1) . '/utils/Constants.php';

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if ($data && isset($data['PlayerID'])) {
    try {
        $cm = new ConnectionManager(Constants::$MYSQL_CONNECTION_STRING, Constants::$MYSQL_USERNAME, Constants::$MYSQL_PASSWORD);
        $pa = new PlayerAccessor($cm->getConnection());
        
        $player = new Player(
            $data['PlayerID'],
            $data['Name'],
            $data['Age'],
            $data['Position'],
            $data['Goals']
        );
        
        $success = $pa->updatePlayer($player);

        echo $success ? json_encode(["status" => "success"]) : json_encode(["status" => "error"]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid input or missing PlayerID."]);
}
?>
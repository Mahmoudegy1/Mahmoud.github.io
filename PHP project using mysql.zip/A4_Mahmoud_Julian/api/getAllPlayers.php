<?php
require_once dirname(__DIR__, 1) . '/db/ConnectionManager.php';
require_once dirname(__DIR__, 1) . '/db/PlayerAccessor.php'; 
require_once dirname(__DIR__, 1) . '/utils/Constants.php';

try {
    $cm = new ConnectionManager(Constants::$MYSQL_CONNECTION_STRING, Constants::$MYSQL_USERNAME, Constants::$MYSQL_PASSWORD);
    $mia = new PlayerAccessor($cm->getConnection());
    $results = $mia->getAllPlayers(); 

    $jsonResults = json_encode($results, JSON_NUMERIC_CHECK);
    
    header('Content-Type: application/json');
    
    echo $jsonResults;
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(["error" => "ERROR: " . $e->getMessage()]);
}
?>

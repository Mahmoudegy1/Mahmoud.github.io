<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Football Player Management</title>
    <link rel="stylesheet" href="mainStyleSheet.css">
    <script src="main.js"></script>
</head>
<body>
    <div id="content" class="container">
        <h1>Player Management</h1>
        
        <button id="LoadButton" class="btn-primary">Load Players</button>

        <div id="ButtonPanel">
            <button id="AddButton" class="btn-primary">Add</button>
            <button id="DeleteButton" class="btn-primary" disabled>Delete</button>
            <button id="UpdateButton" class="btn-primary" disabled>Update</button>
        </div>

        <div id="playerFormContainer" style="display:none;">
            <h2 id="formTitle">Add New Player</h2>
            <form id="playerForm">
                <input type="hidden" name="PlayerID" id="PlayerIDInput">
                <label for="NameInput">Name:</label>
                <input type="text" name="Name" id="NameInput" required><br>
                <label for="AgeInput">Age:</label>
                <input type="number" name="Age" id="AgeInput" required><br>
                <label for="PositionInput">Position:</label>
                <input type="text" name="Position" id="PositionInput" required><br>
                <label for="GoalsInput">Goals:</label>
                <input type="number" name="Goals" id="GoalsInput" required><br>
                <button type="submit">Save</button>
                <button type="button" id="CancelButton">Cancel</button>
            </form>
        </div>

        <div id="PlayersTable">
        </div>
    </div>
</body>
</html>
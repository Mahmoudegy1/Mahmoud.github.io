<?php
require_once dirname(__DIR__, 1) . '/entity/Player.php';

class PlayerAccessor
{
    private $getAllStatementString = "SELECT * FROM Players"; 
    private $getByIDStatementString = "SELECT * FROM Players WHERE PlayerID = :playerID"; 
    private $deleteStatementString = "DELETE FROM Players WHERE PlayerID = :playerID"; 

    private $getAllStatement = null;
    private $getByIDStatement = null;
    private $deleteStatement = null;
    private $conn; 

    /**
     * Creates a new instance of the accessor with the supplied database connection.
     * 
     * @param PDO $conn - a database connection
     */
    public function __construct($conn)
    {
        $this->conn = $conn;
        
        if (is_null($conn)) {
            throw new Exception("no connection");
        }

        $this->getAllStatement = $conn->prepare($this->getAllStatementString);
        if (is_null($this->getAllStatement)) {
            throw new Exception("bad statement: '" . $this->getAllStatementString . "'");
        }

        $this->getByIDStatement = $conn->prepare($this->getByIDStatementString);
        if (is_null($this->getByIDStatement)) {
            throw new Exception("bad statement: '" . $this->getByIDStatementString . "'");
        }

        $this->deleteStatement = $conn->prepare($this->deleteStatementString);
        if (is_null($this->deleteStatement)) {
            throw new Exception("bad statement: '" . $this->deleteStatementString . "'");
        }
    }

    public function getAllPlayers()
    {
        $results = [];
        try {
            $this->getAllStatement->execute();
            $dbresults = $this->getAllStatement->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $playerID = $r['PlayerID'];
                $name = $r['Name'];
                $age = $r['Age'];
                $position = $r['Position'];
                $goals = $r['Goals'];
                $obj = new Player($playerID, $name, $age, $position, $goals);
                array_push($results, $obj);
            }
        } catch (Exception $e) {
            $results = [];
        } finally {
            if (!is_null($this->getAllStatement)) {
                $this->getAllStatement->closeCursor();
            }
        }
        return $results;
    }

    private function getPlayerByID($id)
    {
        $result = null;

        try {
            $this->getByIDStatement->bindParam(":playerID", $id);
            $this->getByIDStatement->execute();
            $dbresults = $this->getByIDStatement->fetch(PDO::FETCH_ASSOC);

            if ($dbresults) {
                $playerID = $dbresults['PlayerID']; 
                $name = $dbresults['Name'];
                $age = $dbresults['Age'];
                $position = $dbresults['Position'];
                $goals = $dbresults['Goals'];
                $result = new Player($playerID, $name, $age, $position, $goals); 
            }
        } catch (Exception $e) {
            $result = null;
        } finally {
            if (!is_null($this->getByIDStatement)) {
                $this->getByIDStatement->closeCursor();
            }
        }

        return $result;
    }

    public function playerExists($player) 
    {
        return $this->getPlayerByID($player->getPlayerID()) !== null; 
    }

    public function deletePlayer($player) 
    {
        if (!$this->playerExists($player)) {
            return false;
        }

        $success = false;
        $playerID = $player->getPlayerID();

        try {
            $this->deleteStatement->bindParam(":playerID", $playerID);
            $success = $this->deleteStatement->execute();
            $success = $success && $this->deleteStatement->rowCount() === 1;
        } catch (PDOException $e) {
            $success = false;
        } finally {
            if (!is_null($this->deleteStatement)) {
                $this->deleteStatement->closeCursor();
            }
        }
        return $success;
    }

    public function addPlayer($player) 
    {
        try {
            $sql = "INSERT INTO Players (Name, Age, Position, Goals) VALUES (:name, :age, :position, :goals)";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(':name', $player->getName());
            $stmt->bindValue(':age', $player->getAge()); 
            $stmt->bindValue(':position', $player->getPosition()); 
            $stmt->bindValue(':goals', $player->getGoals());
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function updatePlayer($player)
    {
        try {
            $sql = "UPDATE Players SET Name = :name, Age = :age, Position = :position, Goals = :goals WHERE PlayerID = :playerID"; // Changed to Players
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(':playerID', $player->getPlayerID()); 
            $stmt->bindValue(':name', $player->getName()); 
            $stmt->bindValue(':age', $player->getAge());
            $stmt->bindValue(':position', $player->getPosition());
            $stmt->bindValue(':goals', $player->getGoals());
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }
}
// end class MenuItemAccessor

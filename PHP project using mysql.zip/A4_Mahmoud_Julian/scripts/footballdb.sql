CREATE DATABASE FootballDB;

USE FootballDB;

CREATE TABLE Players (
    PlayerID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100) NOT NULL,
    Age INT NOT NULL,
    Position VARCHAR(50),
    Goals INT NOT NULL
);

-- insert data (20 entries)
INSERT INTO Players (Name, Age, Position, Goals) VALUES
('Lionel Messi', 37, 'Forward', 700),
('Cristiano Ronaldo', 39, 'Forward', 800),
('Neymar Jr.', 32, 'Forward', 300),
('Kylian Mbappé', 25, 'Forward', 200),
('Kevin De Bruyne', 33, 'Midfielder', 100),
('Luka Modrić', 38, 'Midfielder', 80),
('Sergio Ramos', 38, 'Defender', 50),
('Virgil van Dijk', 33, 'Defender', 20),
('Mohamed Salah', 31, 'Forward', 150),
('Karim Benzema', 36, 'Forward', 600),
('Gareth Bale', 34, 'Forward', 150),
('Harry Kane', 30, 'Forward', 250),
('Marcus Rashford', 26, 'Forward', 120),
('Paul Pogba', 31, 'Midfielder', 70),
('Raheem Sterling', 29, 'Forward', 150),
('Toni Kroos', 34, 'Midfielder', 50),
('Alisson Becker', 31, 'Goalkeeper', 0),
('Jan Oblak', 31, 'Goalkeeper', 0),
('Ederson', 30, 'Goalkeeper', 0),
('Gerard Piqué', 37, 'Defender', 50);

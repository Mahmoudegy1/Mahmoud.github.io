<?php
class Constants
{
    public static $MYSQL_CONNECTION_STRING = "mysql:host=localhost;dbname=footballdb";
    public static $MYSQL_USERNAME = "Mahmoud";
    public static $MYSQL_PASSWORD = "Mahmoud1087@";
}

window.onload = function () {
  // Event listeners for buttons
  document.querySelector("#DeleteButton").addEventListener("click", deletePlayer);
  document.querySelector("#LoadButton").addEventListener("click", getAllPlayers);
  document.querySelector("#AddButton").addEventListener("click", showAddForm);
  document.querySelector("#UpdateButton").addEventListener("click", showUpdateForm);
  document.querySelector("#CancelButton").addEventListener("click", hideForm);
  
  // Form submission handler
  document.querySelector("#playerForm").addEventListener("submit", function (e) {
      e.preventDefault(); // Prevent the default form submission
      submitForm(); // Call submitForm to handle AJAX request
  });
  
  document.querySelector("#PlayersTable").addEventListener("click", handleRowClick);
};

function getAllPlayers() {
  let url = "api/getAllPlayers.php";
  let xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE) {
          if (xhr.status === 200) {
              let resp = xhr.responseText;
              if (resp.search("ERROR") >= 0) {
                  alert("Error loading players: " + resp);
              } else {
                  buildTable(resp);
                  setDeleteUpdateButtonState(false);
              }
          } else {
              alert("Error: " + xhr.status + " - " + xhr.statusText);
          }
      }
  };
  xhr.open("GET", url, true);
  xhr.send();
}

function buildTable(text) {
  let arr = JSON.parse(text);
  let html = "<table><tr><th>Player ID</th><th>Name</th><th>Age</th><th>Position</th><th>Goals</th></tr>";

  for (let i = 0; i < arr.length; i++) {
      let row = arr[i];
      html += "<tr>";
      html += "<td>" + row.playerID + "</td>";
      html += "<td>" + row.name + "</td>";
      html += "<td>" + row.age + "</td>";
      html += "<td>" + row.position + "</td>";
      html += "<td>" + row.goals + "</td>";
      html += "</tr>";
  }
  html += "</table>";

  document.querySelector("#PlayersTable").innerHTML = html;
}

function deletePlayer() {
  let row = document.querySelector(".selected");
  if (!row) {
      alert("Please select a row to delete.");
      return;
  }
  let id = Number(row.querySelectorAll("td")[0].innerHTML);

  let url = "api/deleteItem.php?PlayerID=" + id;
  let xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
          let resp = xhr.responseText;
          if (resp === "1") {
              alert("Player deleted.");
              getAllPlayers();
          } else {
              alert("Error deleting player.");
          }
      }
  };
  xhr.open("GET", url, true);
  xhr.send();
}

function showAddForm() {
  resetForm();
  document.querySelector("#formTitle").innerText = "Add New Player";
  document.querySelector("#playerFormContainer").style.display = "block";
}

function showUpdateForm() {
  let row = document.querySelector(".selected");
  if (!row) {
      alert("Please select a row to update.");
      return;
  }

  let cells = row.querySelectorAll("td");
  let playerData = {
      PlayerID: cells[0].innerHTML,
      Name: cells[1].innerHTML,
      Age: cells[2].innerHTML,
      Position: cells[3].innerHTML,
      Goals: cells[4].innerHTML,
  };

  let form = document.querySelector("#playerForm");
  form.PlayerID.value = playerData.PlayerID;
  form.Name.value = playerData.Name;
  form.Age.value = playerData.Age;
  form.Position.value = playerData.Position;
  form.Goals.value = playerData.Goals;

  document.querySelector("#formTitle").innerText = "Update Player";
  document.querySelector("#playerFormContainer").style.display = "block";
}

function submitForm() {
  let form = document.querySelector("#playerForm");

  let player = {
      PlayerID: form.PlayerID.value,
      Name: form.Name.value,
      Age: form.Age.value,
      Position: form.Position.value,
      Goals: form.Goals.value,
  };

  let url = player.PlayerID ? "api/updateItem.php" : "api/addItem.php";
  let xhr = new XMLHttpRequest();
  xhr.open("POST", url, true);
  xhr.setRequestHeader("Content-Type", "application/json");

  xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
          let response = JSON.parse(xhr.responseText);
          if (response.status === "success") {
              alert(player.PlayerID ? "Player updated successfully!" : "Player added successfully!");
              hideForm();
              getAllPlayers();
          } else {
              alert("Error: " + (response.message || "Unknown error"));
          }
      }
  };

  xhr.send(JSON.stringify(player));
}

function hideForm() {
  document.querySelector("#playerFormContainer").style.display = "none";
}

function resetForm() {
  let form = document.querySelector("#playerForm");
  form.reset();
  form.PlayerID.value = '';
  document.querySelector("#formTitle").innerText = "Add New Player";
}

function setDeleteUpdateButtonState(state) {
  document.querySelector("#DeleteButton").disabled = !state;
  document.querySelector("#UpdateButton").disabled = !state;
}

function handleRowClick(event) {
  let rows = document.querySelectorAll("#PlayersTable tr");
  rows.forEach((row) => row.classList.remove("selected"));

  let selectedRow = event.target.closest("tr");
  if (selectedRow && !selectedRow.querySelector("th")) {
      selectedRow.classList.add("selected");
      setDeleteUpdateButtonState(true);
  } else {
      setDeleteUpdateButtonState(false);
  }
}